export const environment = {
  production: true,
  bpUrl: 'https://5.375.ru/bpo-api/v1',
  bpId: '3275c3846e5d8664755009569d6ff51e',
  dadataUrl: 'https://suggestions.dadata.ru/suggestions/api/4_1/rs',
  baseUrl: 'https://test.flowervalley.ru/back',
};

// В значении по ключу BaseUrl должен лежать путь до бэка проекта, на том же домене, где размещен сам сайт
