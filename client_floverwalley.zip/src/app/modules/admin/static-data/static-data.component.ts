import { Component } from '@angular/core';

@Component({
  selector: 'flower-valley-static-data',
  templateUrl: './static-data.component.html',
  styleUrls: ['./static-data.component.scss'],
})
export class StaticDataComponent {}
