export interface Step {
  id: number;
  countFrom: number;
}
