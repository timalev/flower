export interface Banner {
  autoPlay: number;
  isUserCanLeaf: boolean;
}
