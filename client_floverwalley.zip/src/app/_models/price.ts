export interface Price {
  id: number;
  productId: string;
  countFrom: number;
  price: number;
}
