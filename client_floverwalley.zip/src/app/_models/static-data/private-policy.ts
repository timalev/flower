export interface PrivatePolicy {
  title: string;
  text: string;
}

export enum PrivatePolicyEnum {
  title = 54,
  text,
}
