export interface About {
  img: string;
  title: string;
  subTitle: string;
  description: string;
}

export enum AboutEnum {
  img = 9,
  title,
  subTitle,
  description,
}
