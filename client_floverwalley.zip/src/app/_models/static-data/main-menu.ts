export interface MainMenu extends MainMenuItem {
  id: number;
}

export interface MainMenuItem {
  title: string;
  link: string;
}
