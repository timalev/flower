export interface Video {
  id: number;
  src: string;
  title: string;
  description: string;
  sortOrder: number;
}
