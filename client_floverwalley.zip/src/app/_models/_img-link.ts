import { IdImg } from './_idImg';

export interface ImgLink extends IdImg {
  link: string;
}
