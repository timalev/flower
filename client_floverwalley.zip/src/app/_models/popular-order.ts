export interface PopularOrder {
  order: number;
  id: string;
}
