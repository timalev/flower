export interface ProductOrder {
  productOrder: number;
  productCategoryId: number;
}
