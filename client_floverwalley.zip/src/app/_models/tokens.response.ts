export interface TokensResponse {
  token: string;
  refreshToken: string;
}
