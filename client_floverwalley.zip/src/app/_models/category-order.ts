export interface CategoryOrder {
  id: number;
  categoryOrder: number;
}
