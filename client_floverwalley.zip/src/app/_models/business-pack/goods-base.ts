export interface GoodsBusinessPack {
  Object?: string;
  Name: string;
  Price: number;
  NDS?: number;
  NDSMode?: number;
  Volume?: string;
  Note1?: string;
  Note2?: string;
  Pack?: string;
  Coefficient?: string;
}
