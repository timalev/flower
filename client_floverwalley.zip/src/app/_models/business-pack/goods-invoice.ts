export interface GoodsInvoice {
  model_id?: string;
  volume_id: string;
  model_name?: string;
  nds: number;
  nds_mode: number;
  count: number;
  price: number;
  qname?: string;
}
