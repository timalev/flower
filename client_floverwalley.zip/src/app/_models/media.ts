export interface Media {
  id: number;
  img: string;
  title: string;
  link: string;
  publishDate: Date;
  sortOrder: number;
}
