export interface Discount {
  id: number;
  discount: number;
  sum: number;
  addToPriceList: boolean;
}
