export interface IdImg {
  id: number;
  img: string;
  sortOrder: number;
}
