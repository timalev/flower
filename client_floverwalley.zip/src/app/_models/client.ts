import { IdImg } from './_idImg';

export interface Client extends IdImg {
  autoPlay: number;
  isUserCanLeaf: boolean;
}
