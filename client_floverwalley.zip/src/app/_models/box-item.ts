import { Box } from './box';

export interface BoxItem extends Box {
  count: number;
}
