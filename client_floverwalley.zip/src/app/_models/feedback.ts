import { ImgLink } from './_img-link';

export interface Feedback extends ImgLink {}
