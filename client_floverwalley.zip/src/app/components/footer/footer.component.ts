import { Component, Input } from '@angular/core';
import { AddressData, Footer } from '../../_models/static-data/header';
import { PriceListGenerateService } from '../../_services/front/price-list-generate.service';

@Component({
  selector: 'flower-valley-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss'],
})
export class FooterComponent {
  @Input()
  public footer: Footer | undefined;

  constructor(private pricesPDFService: PriceListGenerateService) {}

  public getPriceList(): void {
    this.pricesPDFService.generatePriceList();
  }

  public getAddressData(): AddressData[] | [] {
    const data: AddressData[] = [];
    if (this.footer) {
      this.footer.address.map((item, index) => {
        data.push({
          address: item,
          workTime: this.footer && this.footer.workTime[index] ? this.footer.workTime[index] : '',
        });
      });
    }
    return data;
  }
}
