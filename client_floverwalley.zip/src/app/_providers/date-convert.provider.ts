import { InjectionToken } from '@angular/core';

export const DATE_CONVERT = new InjectionToken('DATE_CONVERT');
