import { InjectionToken } from '@angular/core';

export const DISCOUNT = new InjectionToken('DISCOUNT');
