import { InjectionToken } from '@angular/core';

export const PRICE_CONVERT = new InjectionToken('PRICE_CONVERT');
