import { InjectionToken } from '@angular/core';

export const STATIC_DATA = new InjectionToken('STATIC_DATA');
